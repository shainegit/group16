const searchIcon=document.querySelector('.search-icon')
const searchForm=document.querySelector('.search-form')
const userIcon=document.querySelector('.user-icon')
const menuIcon=document.querySelector('.menu-icon')
const navbar=document.querySelector('.navbar')

const loginContainer=document.querySelector('.login-container')


userIcon.addEventListener('click', () => {
    loginForm.reset();
    loginContainer.classList.add('active');
    searchForm.classList.remove('active');
    cartItemsContainer.classList.remove('active');
    navbar.classList.remove('active');
})

searchIcon.addEventListener('click', () => {
    searchForm.classList.add('active');
    loginContainer.classList.remove('active');
    cartItemsContainer.classList.remove('active');
    navbar.classList.remove('active');
})

menuIcon.addEventListener('click', () => {
    navbar.classList.add('active');
    loginContainer.classList.remove('active');
    searchForm.classList.remove('active');
    cartItemsContainer.classList.remove('active');
})

const cartIcon=document.querySelector('.cart-icon')
const cartItemsContainer=document.querySelector('.cart-items-container')
cartIcon.addEventListener('click', () => {
    loginContainer.classList.remove('active');
    searchForm.classList.remove('active');
    cartItemsContainer.classList.add('active');
    navbar.classList.remove('active');
})

window.onscroll = ()=>{
    loginContainer.classList.remove('active');
    searchForm.classList.remove('active');
    cartItemsContainer.classList.remove('active');
    navbar.classList.remove('active');
}

window.addEventListener('DOMContentLoaded',()=>{
    fetchJSONData();
    loginForm.addEventListener('submit', validateLoginForm);

})
var APP = APP || {}

function fetchJSONData() {
    fetch("./data.json")
        .then((res) => {
            if (!res.ok) {
                throw new Error
                    (`HTTP error! Status: ${res.status}`);
            }
            return res.json();
        })
        .then((data) => {
            APP.myData = data;
              console.log(data);
              loadCategories();
              loadSubCategories(1)
            })
            
            .catch((error) => 
                   console.error("Unable to fetch data:", error));
  
}
function loadCategories(){
    const preElement = document.getElementById('categories');

    const ul = document.createElement('ul');

    APP.myData.forEach(category => {
      const li = document.createElement('li');
      li.innerHTML = category.CategoryName;

      li.addEventListener('click', function() {
        loadSubCategories(category.CategoryCode);
        var children = this.parentElement.children;
        for (var i = 0; i < children.length; i++) {
          children[i].classList.remove("active")
          
        }

      this.classList.add("active");

        }, false);

      ul.appendChild(li);
      preElement.append(ul);
  });  
}
function loadSubCategories(code){
    const preElement = document.getElementById('subcat');
    while (preElement.firstChild) {
        preElement.removeChild(preElement.lastChild);
      };
    const result = APP.myData.find( ({ CategoryCode }) => CategoryCode === code );
    
    const lbl = document.getElementById('subcatTitle');
    lbl.innerHTML=result.CategoryName;
    const ol = document.createElement('ol');

    result.SubCategories.forEach(subCategory => {

        // let str1 =`<div class="category-card">
        //   <img src="images/10_10.png" alt="">
        //   <h3>${subCategory.SubCategoryName}</h3>
        //   <div class="price">$ 22.99</div>
        //   <a href="" class="btn">add to cart</a>
        // </div>`
  
        d1 = document.createElement('div');
        d1.classList.add('category-card');

        i1 = document.createElement('img');
        imgSrc=`images/${code}_${subCategory.SubCategoryCode}.png`;
        i1.setAttribute("src", imgSrc);
        
        h1 =document.createElement('h3');
        h1.innerHTML=subCategory.SubCategoryName;
        d11 = document.createElement('div');
        d11.classList.add('price');
        d11.innerHTML='$ 22.99';
        d1.append(...[i1, h1, d11]);
        preElement.appendChild(d1);
    });



}

function resetContactForm() {
    document.getElementById("contactForm").reset();
  }
function resetloginForm() {
    loginForm.reset();
}


const loginForm= document.getElementById("loginForm");

loginForm.addEventListener('submit', validateLoginForm);

function validateLoginForm(event) {
  
    event.preventDefault();

    const email = document.getElementById('email');
    const password = document.getElementById('password');
    const errorMessages = document.getElementById('errorMessages');

    errorMessages.innerHTML = '';

    // Validate email
    if (!validateEmail(email.value)) {
        
        errorMessages.innerHTML += '<p>Please enter a valid email address.</p>';
        return;
    }

    // Validate password
    if (!validatePassword(password.value)) {
  
        errorMessages.innerHTML += '<p>Please enter a valid password.</p>';
        return;
    }

    // If all validations pass, submit the form
    alert('Login successful!');
}

function validateEmail(email) {
    // Use a regular expression to check if the email is valid
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
}
function validatePassword(password) {
    // Customize these rules to match your password requirements
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumber = /\d/.test(password);

    return (
        password.length >= minLength &&
        hasUpperCase &&
        hasLowerCase &&
        hasNumber
    );
}

//function loadLoginForm() {
//    const preElement = document.getElementById('header');
//    d1 = document.createElement('div');
//    d1.classList.add('login-container');
//    d1.innerHTML = `<form id="loginForm">
//            <h3>Login</h3>
//            <div class="input-box">
//                <input type="email" name="email" id="email" required placeholder="email">
//            </div>
//            <div class="input-box">
//                <input type="password" name="password" id="password" required placeholder="password">
//            </div>
//            <div id="errorMessages" style="color: red;"></div>

//            <button type="submit" id="loginSubmit" class="btn">Login</button>
//        </form>`;

//    preElement.appendChild(d1);
//}

function loadFooter() {
    const preElement = document.getElementById('footer');
    d1 = document.createElement('div');
    d1.classList.add('social-media');
    d1.innerHTML = `<a href="" class="fab fa-facebook"></a>
            <a href="" class="fab fa-twitter"></a>
            <a href="" class="fab fa-instagram"></a>
            <a href="" class="fab fa-linkedin"></a>
            <a href="" class="fab fa-pinterest"></a>`;
    preElement.appendChild(d1);

    d2 = document.createElement('div');
    d2.classList.add('links');
    d2.innerHTML = `<a href="index.html">Home</a>
            <a href="about.html">About</a>
            <a href="">Product Request</a>
            <a href="contact.html">Contact</a>`;
    preElement.appendChild(d2);


    d3 = document.createElement('div');
    d3.classList.add('credits');
    d3.innerHTML = `created by <span>Shaine and Tal</span> &copy; all rights reserved.`;
    preElement.appendChild(d3);

}

loadFooter();