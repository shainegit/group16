import os
import ssl
import certifi
from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv()

client = MongoClient('mongodb+srv://admin:admin@cluster0.elaqd5v.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', tlsCAFile=certifi.where())
DB = client.db

def print_contact():
    collection = DB['Contacts']
    documents = collection.find({})
    print("Contacts")
    for document in documents:
        print(document)
        
def print_users():
    collection = DB['Users']
    documents = collection.find({})
    print("Users")
    for document in documents:
        print(document)
        
        
print_contact()
print_users()