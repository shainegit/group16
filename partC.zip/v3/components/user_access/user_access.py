from flask import Blueprint, flash, redirect, url_for, request
from settings import DB

user_access = Blueprint('auth', __name__)

@user_access.route('/sign-in', methods=['POST'])
def sign_in():
    if request.method == 'POST':
        is_register = request.form.get('is_register')
        email = request.form['email']
        password = request.form['password']
        users_collection = DB['Users']
        existing_user = users_collection.find_one({'email': email})

        if is_register == 'on':
            if existing_user:
                errors = {'Email already exists. Please use a different email.'}
                return redirect(url_for('homepage.index'), errors=errors)
            else:
                new_user = {
                    'email': email,
                    'pwd': password
                }
                users_collection.insert_one(new_user)
                return redirect(url_for('homepage.index',msg='Registration Successful.'))

        if existing_user:
            user = users_collection.find_one({'email': email, 'pwd': password})
            if user:
                msg='Login Successful'
                return redirect(url_for('homepage.index', msg=msg))
            else:
                return redirect(url_for('homepage.index', msg="Invalid email or password. Please try again."))
                
        else:
            return redirect(url_for('homepage.index', msg="Invalid email or password. Please try again."))

    return redirect(url_for('homepage.index', errors=errors))
