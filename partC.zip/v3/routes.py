from flask import Blueprint, jsonify
import json

products_router = Blueprint('products', __name__)

@products_router.route('/products', methods=['GET'])
def get_products():
    json_file_path = 'data.json'

    try:
        # Open and read the JSON file
        with open(json_file_path, 'r') as file:
            # Parse the JSON data
            products = json.load(file)

        # Return the JSON data as a response
        return jsonify(products)

    except FileNotFoundError:
        return jsonify({'error': 'JSON file not found'})
