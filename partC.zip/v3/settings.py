import os
import ssl
import certifi

from dotenv import load_dotenv
load_dotenv()
from pymongo import MongoClient
# Secret key setting from .env for Flask sessions
SECRET_KEY = os.environ.get('SECRET_KEY')


client = MongoClient('mongodb+srv://admin:admin@cluster0.elaqd5v.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0',tlsCAFile=certifi.where())
DB = client.db
