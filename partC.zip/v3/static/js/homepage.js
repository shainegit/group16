
let products = []
window.addEventListener('DOMContentLoaded',async()=>{
    const response = await fetch("/products")
    products = await response.json()
    console.log(products)
    loadCategories()
})

function loadCategories(){
    const preElement = document.getElementById('categories');

    const ul = document.createElement('ul');

    products.forEach(category => {
      const li = document.createElement('li');
      li.innerHTML = category.CategoryName;

      li.addEventListener('click', function() {
        loadSubCategories(category.CategoryCode);
        var children = this.parentElement.children;
        for (var i = 0; i < children.length; i++) {
          children[i].classList.remove("active")

        }

      this.classList.add("active");

        }, false);

      ul.appendChild(li);
      preElement.append(ul);
  });
              loadSubCategories(1)

}
function loadSubCategories(code){
    const preElement = document.getElementById('subcat');
    while (preElement.firstChild) {
        preElement.removeChild(preElement.lastChild);
      };
    const result = products.find( ({ CategoryCode }) => CategoryCode === code );

    const lbl = document.getElementById('subcatTitle');
    lbl.innerHTML=result.CategoryName;
    const ol = document.createElement('ol');

    result.SubCategories.forEach(subCategory => {

        d1 = document.createElement('div');
        d1.classList.add('category-card');

        i1 = document.createElement('img');
        imgSrc=`static/images/${code}_${subCategory.SubCategoryCode}.png`;
        i1.setAttribute("src", imgSrc);

        h1 =document.createElement('h3');
        h1.innerHTML=subCategory.SubCategoryName;
        d11 = document.createElement('div');
        d11.classList.add('price');
        d11.innerHTML='$ 22.99';
        d1.append(...[i1, h1, d11]);
        preElement.appendChild(d1);
    });



}
