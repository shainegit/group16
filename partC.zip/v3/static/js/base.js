const searchIcon = document.querySelector(".search-icon");
const searchForm = document.querySelector(".search-form");
const userIcon = document.querySelector(".user-icon");
const menuIcon = document.querySelector(".menu-icon");
const navbar = document.querySelector(".navbar");

const loginContainer = document.querySelector(".login-container");

userIcon.addEventListener("click", () => {
  loginForm.reset();
  loginContainer.classList.add("active");
  searchForm.classList.remove("active");
  if (cartItemsContainer) {
    cartItemsContainer.classList.remove("active");
  }
  navbar.classList.remove("active");
});

searchIcon.addEventListener("click", () => {
  searchForm.classList.add("active");
  loginContainer.classList.remove("active");
  if (cartItemsContainer) {
    cartItemsContainer.classList.remove("active");
  }
  navbar.classList.remove("active");
});

menuIcon.addEventListener("click", () => {
  navbar.classList.add("active");
  loginContainer.classList.remove("active");
  searchForm.classList.remove("active");
  if (cartItemsContainer) {
    cartItemsContainer.classList.remove("active");
  }
});

const cartIcon = document.querySelector(".cart-icon");
const cartItemsContainer = document.querySelector(".cart-items-container");
cartIcon.addEventListener("click", () => {
  loginContainer.classList.remove("active");
  searchForm.classList.remove("active");
  if (cartItemsContainer) {
    cartItemsContainer.classList.add("active");
  }
  navbar.classList.remove("active");
});

window.onscroll = () => {
  loginContainer.classList.remove("active");
  searchForm.classList.remove("active");
  if (cartItemsContainer) {
    cartItemsContainer.classList.remove("active");
  }
  navbar.classList.remove("active");
};

window.addEventListener("DOMContentLoaded", () => {
  // loginForm.addEventListener('submit', validateLoginForm);
});

function resetContactForm() {
  document.getElementById("contactForm").reset();
}
function resetloginForm() {
  loginForm.reset();
}
function validateContactForm() {
  const contactname = document.getElementById("contactname");
  const email = document.getElementById("contactemail");
  const errorMessages = document.getElementById("cferrorMessages");
  errorMessages.innerHTML = "";

  // Validate email
  if (!validateEmail(email.value)) {
    errorMessages.innerHTML += "<p>Please enter a valid email address.</p>";
    //event.preventDefault();
    return false;
  }

  // Validate contactname
  if (contactname.value.length == 0) {
    //event.preventDefault();
    errorMessages.innerHTML += "<p>Please enter name.</p>";
    return false;
  }
  // return true;
}

const loginForm = document.getElementById("loginForm");

// loginForm.addEventListener('submit', validateLoginForm);

function validateLoginForm(event) {
  const email = document.getElementById("email");
  const password = document.getElementById("password");
  const errorMessages = document.getElementById("errorMessages");

  errorMessages.innerHTML = "";

  // Validate email
  if (!validateEmail(email.value)) {
    errorMessages.innerHTML += "<p>Please enter a valid email address.</p>";
    event.preventDefault();
    return;
  }

  // Validate password
  if (!validatePassword(password.value)) {
    errorMessages.innerHTML += "<p>Please enter a valid password.</p>";
    event.preventDefault();
    return;
  }

  // If all validations pass, submit the form
  //    alert('Login successful!');
}

function validateEmail(email) {
  // Use a regular expression to check if the email is valid
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(email);
}
function validatePassword(password) {
  // Customize these rules to match your password requirements
  const minLength = 8;
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumber = /\d/.test(password);

  return (
    password.length >= minLength && hasUpperCase && hasLowerCase && hasNumber
  );
}

window.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const msg = params.get("msg");
  if (msg!==null) {alert(msg)};
});
