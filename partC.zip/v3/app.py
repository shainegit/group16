from flask import Flask,Blueprint,jsonify
from pages.homepage.homepage import homepage
from pages.about.about import about
from pages.contact.contact import contact
from pages.login.login import login
from pages.register.register import register

from pages.profile.profile import profile
from pages.menu.menu import menu
from pages.product_request.product_request import product_request
from components.main_menu.main_menu import main_menu
from routes import products_router

from components.user_access.user_access import user_access

app = Flask(__name__)
app.config.from_pyfile('settings.py')


app.register_blueprint(homepage)
app.register_blueprint(about)
app.register_blueprint(contact)
app.register_blueprint(login)
app.register_blueprint(register)
app.register_blueprint(profile)
app.register_blueprint(menu)
app.register_blueprint(product_request)

app.register_blueprint(user_access)
app.register_blueprint(products_router)



app.register_blueprint(main_menu)

if __name__ == "__main__":
    app.run(port=3000)
