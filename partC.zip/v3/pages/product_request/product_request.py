from flask import Blueprint, render_template

# product_request blueprint definition
product_request = Blueprint('product_request', __name__, static_folder='static', static_url_path='/product_request', template_folder='templates')


# Routes
@product_request.route('/product_request')
def index():
    return render_template('product_request.html')
