from flask import Blueprint, redirect, render_template, request, url_for
from settings import DB
import datetime
contact = Blueprint(
    'contact',
    __name__,
    static_folder='static',
    static_url_path='/contact',
    template_folder='templates'
)


# Routes
@contact.route("/contact", methods=["GET","POST"])
def index():
    if request.method == 'POST':
        contactname = request.form['contactname']
        email = request.form['contactemail']
        phone = request.form['contactphone']
        if len(email)> 0 and len(contactname)>0 :
            # Check if the username and password match
            dt = datetime.datetime.utcnow()
            ts = dt.timestamp()
            contacts_collection = DB['Contacts']
            contacts_collection.insert_one({'contactname': contactname, 'email': email, 'phone': phone, 'timestamp':datetime.datetime.fromtimestamp(ts)})
            return redirect(url_for('contact.index', msg="Thanks, we received your contact info, will revert back asap."))

    return render_template('contact.html')


